import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class TestePerson {
    private Person person;

    @BeforeEach
    public void setUp() {
        // Create a Person object before each test
        Date birthday = new Date(90, 0, 1); // January 1, 1990
        Date entryDate = new Date(2020, 5, 1); // June 1, 2020
        person = new Person("John Doe", birthday, entryDate);
    }

    @AfterEach
    public void tearDown() {
        // Clean up the Person object after each test
        person = null;
    }

    @Test
    public void testGetName() {
        assertEquals("John Doe", person.getName());
    }

    @Test
    public void testSetName() {
        person.setName("Jane Smith");
        assertEquals("Jane Smith", person.getName());
    }

    @Test
    public void testGetDateBirthday() {
        Date expectedBirthday = new Date(90, 0, 1); // January 1, 1990
        assertEquals(expectedBirthday, person.getDateBirthday());
    }

    @Test
    public void testSetDateBirthday() {
        Date newBirthday = new Date(95, 2, 15); // March 15, 1995
        person.setDateBirthday(newBirthday);
        assertEquals(newBirthday, person.getDateBirthday());
    }

    @Test
    public void testGetEntryDate() {
        Date expectedEntryDate = new Date(2020, 5, 1); // June 1, 2020
        assertEquals(expectedEntryDate, person.getEntryDate());
    }

    @Test
    public void testSetEntryDate() {
        Date newEntryDate = new Date(2022, 8, 15); // September 15, 2022
        person.setEntryDate(newEntryDate);
        assertEquals(newEntryDate, person.getEntryDate());
    }
}
