
/**
 * Enumeração TeamLevel - escreva a descrição da enumeração aqui
 * 
 * @author (seu nome aqui)
 * @version (número da versão ou data aqui)
 */
public enum TeamLevel {
    PETIZES("S7", "Sub-7 Petizes"),
    TRAQUINAS("S9", "Sub-9 Traquinas"),
    BENJAMINS("S11", "Sub-11 Benjamins");

    public String abbreviation;
    public String description;

    TeamLevel(String abbreviation, String description) {
        this.abbreviation = abbreviation;
        this.description = description;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public String getDescription() {
        return description;
    }

    public static TeamLevel fromAbbreviation(String abbreviation) {
        for (TeamLevel level : TeamLevel.values()) {
            if (level.abbreviation.equals(abbreviation)) {
                return level;
            }
        }
        return null;
    }
}

