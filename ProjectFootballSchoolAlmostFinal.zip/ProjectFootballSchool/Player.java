import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;
import java.util.Scanner;





public class Player extends Person implements Serializable {
    int option;
    private InputReader reader;
    private ArrayList<Player> players;
    public int numberShirt;
    private static int numberPlayers = 0;
    private int playerNumber;
    private int numberRegister;
    private int coachNumber;
    private int rating;
    private static final String PLAYER_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/player_data.bin";
     private static final String TRAINER_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/trainer_data.bin";
    private static final long serialVersionUID = 1L;
    private static int nextPlayerNumber = 1; // Initialize with the starting player number
    private Team team;
    private Trainer trainer;
   private List<Integer> playerRatings = new ArrayList<>();
   private ArrayList<Trainer> trainers;
   private ArrayList<Team> teams;

// New instance variable




    public Player(String name, Date dateBirthday, Date entryDate, int numberShirt) {
        super(name, dateBirthday, entryDate);
        this.playerNumber = ++numberPlayers;
        this.numberShirt = numberShirt;
        //this.rating = 0;
        
        this.playerRatings = new ArrayList<>(); // Initialize the playerRatings list
    }

    
     public Player()
    {
        // inicializa variáveis de instância
        players = new ArrayList<>();
        reader = new InputReader();
        playerRatings = new ArrayList<>();
    }
    
    
    public int getPlayerNumber() {
        return this.playerNumber;
    }
    
    public void setPlayerNumber(int playerNumber) {
        this.playerNumber = playerNumber;
    }
        
    public static int getNumberPlayers() {
        return numberPlayers; 
    }
    
    public int getNumberShirt() {
        return numberShirt;
    }
    
    public void setNumberShirt(int numberShirt) {
        this.numberShirt = numberShirt;
    }
    
    public int getNumberRegister() {
        return numberRegister;
    }
    
    public int getRating() {
        return rating;
    }
    
    public void setRating(int newRating) {
        this.rating = newRating;
    }

    
    public int getCoachNumber() {
        return coachNumber;
    }
    
    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }
    
    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
    
    public List<Integer> getPlayerRatings() {
        if (playerRatings == null) {
            playerRatings = new ArrayList<>();
        }
        return playerRatings;
    }
    
     public void addRating(int rating) {
        getPlayerRatings().add(rating);
        recalculateRating();
    }
    
    public void recalculateRating() {
        int sum = 0;
        for (int r : getPlayerRatings()) {
            sum += r;
        }
        this.rating = getPlayerRatings().isEmpty() ? 0 : sum;
    }

    public void makePlayer() {
    boolean addAnother = true;

    while (addAnother) {
        System.out.println("_____________________________________");
        System.out.println("\n************** Inserir uma nova ficha *******************\n\t\t\t\t");
        setName(reader.getName("Nome do Jogador: "));
        setDateBirthday(reader.getDate("Data de nascimento (dd/MM/yyyy): "));
        setEntryDate(new Date());

        int numberShirt = -1;
        boolean validNumber = false;

        while (!validNumber) {
            System.out.print("Número da camisola: ");
            numberShirt = Integer.parseInt(reader.nextLine());
            boolean numberExists = false;
            for (Player player : players) {
                if (player.getNumberShirt() == numberShirt) {
                    System.out.println("Erro: Este número de camisola já existe. Por favor, insira um número diferente.");
                    numberExists = true;
                    break;
                }
            }

            if (!numberExists) {
                validNumber = true;
            }
        }

        System.out.println("\t\t\t******** Criado com sucesso ********\t\t\t");
        Player currentPlayer = new Player(getName(), getDateBirthday(), getEntryDate(), numberShirt);
        players.add(currentPlayer);
        numberPlayers = players.size();
        System.out.print("Deseja adicionar outro jogador? (s/n): ");
        String input = reader.nextLine();
        if (!input.equalsIgnoreCase("s")) {
            addAnother = false;
        }
    }
}



   public void changePlayerInfo() {
    if (players.isEmpty()) {
        System.out.println("Não há jogadores cadastrados.");
        return;
    }

    boolean continueChanging = true;

    while (continueChanging) {
        System.out.println("_____________________________________");
        System.out.println("\n************** Alterar Jogador *******************\n\t\t\t\t");
        int playerNumber = reader.getNumberPlayers("Digite o número do jogador:");
        Player player = null;

        for (Player p : players) {
            if (p.getPlayerNumber() == playerNumber) {
                player = p;
                break;
            }
        }

        if (player == null) {
            System.out.println("Jogador não encontrado.");
            continue;
        } else {
            System.out.println("Informações do jogador " + player.getPlayerNumber() + " >");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            System.out.println("Nome do Jogador: " + player.getName());
            System.out.println("Data de nascimento: " + sdf.format(player.getDateBirthday()));
            System.out.println("Data de entrada: " + sdf.format(player.getEntryDate()));
            System.out.println("Número da camisola: " + player.getNumberShirt());       
            System.out.println("O que deseja alterar?");
            int option = Menu.menuAlterarJogador();

            switch (option) {
                case 1:
                    System.out.println("Alterando todas as informações do jogador " + player.getPlayerNumber() + "...");
                    String newName = reader.getName("Nome do Jogador novo: ");
                    Date newDateBirthday = reader.getDateBirthday("Data de nascimento novo: ");

                    boolean validNumber = false;
                    int newNumberShirt = -1;
                    while (!validNumber) {
                        newNumberShirt = reader.getNumberShirt("Número da camisola novo: ");
                        boolean numberExists = false;

                        for (Player p : players) {
                            if (p.getNumberShirt() == newNumberShirt && p != player) {
                                System.out.println("Erro: Este número de camisola já existe para outro jogador. Por favor, insira um número diferente.");
                                numberExists = true;
                                break;
                            }
                        }

                        if (!numberExists) {
                            validNumber = true;
                        }
                    }

                    player.setName(newName);
                    player.setDateBirthday(newDateBirthday);
                    player.setNumberShirt(newNumberShirt);

                    System.out.println("Todas as informações do jogador " + player.getPlayerNumber() + " foram alteradas com sucesso.");
                    break;

                case 2:
                    System.out.println("Nome do Jogador atual: " + player.getName());
                    String name = reader.getName("Nome do Jogador novo: ");
                    player.setName(name);
                    System.out.println("Alterado com sucesso. Nome atual do jogador " + player.getPlayerNumber() + ": " + player.getName());
                    break;

                case 3:
                    Date oldDateBirthday = player.getDateBirthday();
                    System.out.println("Data de nascimento atual: " + sdf.format(oldDateBirthday));
                    Date dateBirthday = reader.getDateBirthday("Data de nascimento novo: ");
                    player.setDateBirthday(dateBirthday);
                    System.out.println("Alterado com sucesso. Data de nascimento atual do jogador " + player.getPlayerNumber() + ": " + sdf.format(dateBirthday));
                    break;

                
                case 4:
                    int oldNumberShirt = player.getNumberShirt();
                    System.out.println("Número da camisola atual: " + oldNumberShirt);

                    boolean validNumberShirt = false;
                    //int newNumberShirt;

                    while (!validNumberShirt) {
                        newNumberShirt = reader.getNumberShirt("Número da camisola novo: ");
                        boolean numberExists = false;

                        for (Player p : players) {
                            if (p.getNumberShirt() == newNumberShirt && p != player) {
                                System.out.println("Erro: Este número de camisola já existe para outro jogador. Por favor, insira um número diferente.");
                                numberExists = true;
                                break;
                            }
                        }

                        if (!numberExists) {
                            validNumberShirt = true;
                            player.setNumberShirt(newNumberShirt);
                        }
                    }

                    System.out.println("Número da camisola alterado com sucesso.");
                    break;

                case 5:
                    break;

                default:
                    System.out.println("Opção inválida. Por favor, tente novamente.");
                    break;
            }
        }

        continueChanging = reader.getBoolean("Deseja alterar mais alguma informação do jogador? (s/n)");
    }
    }




    
    public void searchPlayer() {
        if (players.isEmpty()) {
            System.out.println("Não há jogadores cadastrados.");
            return;
        }
    
        boolean continueSearching = true;
        while (continueSearching) {
            System.out.println("_____________________________________");
            System.out.println("\n************** Procurar Jogador *******************\n\t\t\t\t");
            int playerNumber = reader.getNumberPlayers("Digite o número do jogador:");
            Player player = null;
            for (Player p : players) {
                if (p.getPlayerNumber() == playerNumber) {
                    player = p;
                    break;
                }
            }
            if (player == null) {
                System.out.println("Jogador não encontrado.");
            } else {
                System.out.println("Informações do jogador " + playerNumber + " >");
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                System.out.println("Nome do Jogador: " + player.getName());
                System.out.println("Data de nascimento: " + sdf.format(player.getDateBirthday()));
                System.out.println("Data de entrada: " + sdf.format(player.getEntryDate()));
                System.out.println("Número da camisola: " + player.getNumberShirt());
            }
    
            System.out.println("Deseja continuar procurando jogadores? (s/n)");
            String input = reader.getStringInput();
            continueSearching = input.equalsIgnoreCase("s");
        }
    }


    
    public void showPlayersContainsName(String search) {
        System.out.println("---- Jogadores cujo nome contém \"" + search + "\" ----\n");
        
        for (Player player : players) {
            String playerName = player.getName();
            
            if (playerName.toLowerCase().contains(search.toLowerCase())) {
                System.out.println("Número de Jogador: " + player.getPlayerNumber());
                System.out.println("Nome: " + playerName);
                // Print other player details if needed
                System.out.println("-------------------------");
            }
        }
    }

    
  public void showAllPlayers() {
        if (players.isEmpty()) {
            System.out.println("Nenhum jogador cadastrado.");
        } else {
            System.out.println("\n----Lista de jogadores----\n");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            for (Player player : players) {
                System.out.println("Número de Jogador: " + player.getPlayerNumber());
                System.out.println("Nome: " + player.getName());
                System.out.println("Data de nascimento: " + sdf.format(player.getDateBirthday()));
                System.out.println("Data de entrada: " + sdf.format(player.getEntryDate()));
                System.out.println("Número da camisola: " + player.getNumberShirt());
                System.out.println("Classificação: " + this.getRating());
                int trainerClassification = getTrainerClassification(player.getPlayerNumber());
                player.setRating(trainerClassification); // Set the player's rating from the trainer
                System.out.println("---------------\n");
            }
        }
    }

    private int getTrainerClassification(int playerNumber) {
        return getRating(); 
    }

    
    public void removePlayerByNumber(int playerNumber) {
        Player playerToRemove = null;
        for (Player player : players) {
            if (player.getPlayerNumber() == playerNumber) {
                playerToRemove = player;
                break;
            }
        }
    
        if (playerToRemove == null) {
            System.out.println("Jogador não encontrado.");
            return;
        }
    
        System.out.println("Informações do jogador " + playerToRemove.getPlayerNumber() + " >");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println("Nome do Jogador: " + playerToRemove.getName());
        System.out.println("Data de nascimento: " + sdf.format(playerToRemove.getDateBirthday()));
        System.out.println("Data de entrada: " + sdf.format(playerToRemove.getEntryDate()));
        System.out.println("Número da camisola: " + playerToRemove.getNumberShirt());
    
        boolean confirmDeletion = reader.getBoolean("Deseja realmente excluir este jogador? (s/n)");
        if (confirmDeletion) {
            players.remove(playerToRemove);
            System.out.println("Jogador removido com sucesso.");
        } else {
            System.out.println("Eliminação cancelada. Voltando ao menu...");
        }
    }      
   
    public void savePlayerData(String fileName) {
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            objectOutputStream.writeObject(players);
            objectOutputStream.writeInt(nextPlayerNumber); // Save the nextPlayerNumber
            System.out.println("Player data saved successfully to " + fileName);
        } catch (FileNotFoundException e) {
            System.out.println("Player data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving player data to " + fileName + ": " + e.getMessage());
        }
    }

    public void loadPlayerData(String fileName) {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(fileName))) {
            players = (ArrayList<Player>) objectInputStream.readObject();
            numberPlayers = players.size(); // Update the numberPlayers variable
            System.out.println("Player data loaded successfully from " + fileName);

            // Recalculate ratings for all players
            for (Player player : players) {
                player.getRating();
            }
        } catch (FileNotFoundException e) {
            System.out.println("Player data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error loading player data from " + fileName + ": " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading player data: " + e.getMessage());
        }
    }
    public void loadTrainerData(String fileName) {
        try (InputStream inputStream = new FileInputStream(fileName);
             ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
    
            // Read the trainers and teams lists from the file
            trainers = (ArrayList<Trainer>) objectInputStream.readObject();
            teams = (ArrayList<Team>) objectInputStream.readObject();
    
            System.out.println("Trainer data loaded successfully from " + fileName);
        } catch (Exception e) {
            System.out.println("Error loading trainer data from " + fileName + ": " + e.getMessage());
        }
    }

}
