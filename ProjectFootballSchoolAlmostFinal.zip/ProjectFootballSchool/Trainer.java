import java.util.Scanner;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.List;
import java.text.SimpleDateFormat;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collections;



/**
 * Escreva uma descrição da classe Trainer aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Trainer extends Person implements Serializable
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
   private InputReader reader;
    private ArrayList<Trainer> trainers;
    private ArrayList<Player> players;
    private TrainerCategory category;
    private static int numberTrainers = 0;
    private int trainerNumber;
    public int playerNumber;
     private static final String TRAINER_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/trainer_data.bin";
     private static final String TEAM_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/teams_data.bin";
     private static final String PLAYER_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/player_data.bin";
     private static final long serialVersionUID = 1L;
     private ArrayList<Team> teams;
    private Team team;
    public int total;

        /**
         * Construtor para objetos da classe Trainer
         */
        
    
    public Trainer(String name, Date dateBirthday, Date entryDate, TrainerCategory category) {
        super(name, dateBirthday, entryDate);
        this.category =category;
        this.trainerNumber = ++numberTrainers;
    }
    
    public Trainer()
    {
        // inicializa variáveis de instância
        this.trainers = new ArrayList<>();
        reader = new InputReader();
        teams = new ArrayList<>();
        players = new ArrayList<>();
        loadTeamData(TEAM_DATA_FILE);
       
    }
    
    public int getTrainerNumber() {
        return trainerNumber;
    }
        
    public static int getNumberTrainers() {
        return numberTrainers;
    }
    
    
    public TrainerCategory getCategory(){
        return category;
    }
    
    public void setCategory(TrainerCategory category) {
        this.category = category;
    }


    public ArrayList<Player> getPlayers() {
        return players;
    }

    
    public void addTeam(Team team) {
        teams.add(team);
    }
    
    public void setTeam(Team team) {
        this.team = team;
    }

    public Team getTeam() {
        return team;
    }
    
    
    public void setTotal(int total) {
        this.total = total;
    }

    public int getTotal() {
        return total;
    }
    
    

    
    
    public void evaluatePlayers(Scanner scanner, List<Integer> playerRatings) {
        loadTrainerData(TRAINER_DATA_FILE); // Load the trainer data
        loadTeamData(TEAM_DATA_FILE); // Load the trainer data
        System.out.print("Introduza o número do treinador: ");
        int trainerNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
    
        Trainer selectedTrainer = null;
        Team selectedTeam = null;
        for (Team team : teams) {
            Trainer trainer = team.getSelectedTrainer();
            if (trainer.getTrainerNumber() == trainerNumber) {
                selectedTrainer = trainer;
                selectedTeam = team;
                break;
            }
        }
    
        if (selectedTrainer == null || selectedTeam == null) {
            System.out.println("Número de treinador inválido ou não tens equipa para classificar os jogadores..");
            return;
        }
        System.out.println("Equipa: " + selectedTeam.getTeamName() + " -- " + "Escalão: " + selectedTeam.getTeamLevel()); // Display the team name and team level
    
        System.out.println("Jogadores na equipa:");
    
        // Display information of players in the team
        for (Player player : selectedTeam.getSelectedPlayers()) {
            System.out.println("Numero do Jogador: " + player.getPlayerNumber());
            System.out.println("Nome do Jogador: " + player.getName());
            System.out.println("Classificação atual: " + player.getRating());
            System.out.println("-------------------");
        }
    
        System.out.print("Introduza o numero de jogador para classificar: ");
        int playerNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
    
        // Find the player in the team
       Player player = selectedTeam.getPlayerByNumber(playerNumber);
    
        if (player != null) {
        System.out.print("Introduza a classificação para aumentar a atual " + player.getRating() + ": ");
        int newRating = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
    
        // Validate the new rating value
        if (newRating >= 0 && newRating <= 100) {
            int currentRating = player.getRating(); // Get the current rating
            int newTotalRating = currentRating + newRating; // Calculate the new total rating
            
            if (newTotalRating > 100) {
                newRating = 100 - currentRating; // Limit the new rating to avoid exceeding 100
                newTotalRating = 100; // Set the new total rating to 100
                System.out.println("A classificação excede o valor máximo de 100. Será ajustada para " + newRating);
            }
            
            player.addRating(newRating);
            player.recalculateRating(); // Recalculate the average rating
            System.out.println("Jogador " + playerNumber + " (" + player.getName() + ") agora tem a classificação de " + player.getRating());
            
            String performanceClassification = determinePerformanceClassification(selectedTeam.getTeamLevel(), player.getRating());
            System.out.println("Classificação de desempenho: " + performanceClassification);
        } else {
            System.out.println("Classificação inválida. A nota deve estar entre 0 e 100.");
        }



        } else {
            System.out.println("Número de jogador inválido ou jogador que não faz parte do seu time.");
        }

    }
    
    private String determinePerformanceClassification(TeamLevel teamLevel, int playerRating) {
    if (teamLevel == TeamLevel.PETIZES) {
        if (playerRating >= 70) {
            return "Estrela";
        } else if (playerRating >= 40) {
            return "Promessa";
        } else {
            return "Regular";
        }
    } else if (teamLevel == TeamLevel.TRAQUINAS) {
        if (playerRating >= 80) {
            return "Estrela";
        } else if (playerRating >= 50) {
            return "Promessa";
        } else {
            return "Regular";
        }
    } else if (teamLevel == TeamLevel.BENJAMINS) {
        if (playerRating >= 90) {
            return "Estrela";
        } else if (playerRating >= 60) {
            return "Promessa";
        } else {
            return "Regular";
        }
    } else {
        return "Desconhecido";
    }
}





   public Team findTeamByTrainerNumber(int trainerNumber) {
        for (Team team : teams) {
            Trainer selectedTrainer = team.getSelectedTrainer();
            if (selectedTrainer != null && selectedTrainer.getTrainerNumber() == trainerNumber) {
                return team;
            }
        }
        return null;
    }

    
    public void makeTrainer() {
    boolean addAnother = true;
    while (addAnother) {
        System.out.println("_____________________________________");
        System.out.println("\n************** Inserir uma nova ficha *******************\n\t\t\t\t");
        String name = reader.getName("Nome do Treinador: ");
        System.out.print("Data de nascimento (dd/MM/yyyy): ");
        String dateBirthdayString = reader.nextLine();
        Date dateBirthday = null;

        try {
            dateBirthday = new SimpleDateFormat("dd/MM/yyyy").parse(dateBirthdayString);
        } catch (ParseException e) {
            System.out.println("Erro ao converter data. Certifique-se de usar o formato dd/MM/yyyy.");
            continue; // Restart the loop if the date parsing fails
        }

        Date entryDate = new Date();
        TrainerCategory category = getTrainerCategory();
        System.out.println("\t\t\t******** Criado com sucesso ********\t\t\t");
        trainers.add(new Trainer(name, dateBirthday, entryDate, category));
        addAnother = reader.getBoolean("Deseja adicionar outro treinador? (s/n)");
    }
}



    
    private TrainerCategory getTrainerCategory() {
        Scanner scanner = new Scanner(System.in);
        String input;
        TrainerCategory category = null;
        boolean isValidInput = false;
        do {
            System.out.print("Categoria do treinador (TP/TA/PP/GR): ");
            input = scanner.nextLine().toUpperCase();
            switch (input) {
                case "TP":
                    category = TrainerCategory.MAIN;
                    isValidInput = true;
                    break;
                case "TA":
                    category = TrainerCategory.ASSISTANT;
                    isValidInput = true;
                    break;
                case "PP":
                    category = TrainerCategory.PERSONAL;
                    isValidInput = true;
                    break;
                case "GR":
                    category = TrainerCategory.GOALKEEPER;
                    isValidInput = true;
                    break;
                case "HELP":
                    System.out.println("Opções de categoria: ");
                    for (TrainerCategory c : TrainerCategory.values()) {
                        System.out.println(c.toChar() + " - " + c.toString());
                    }
                    break;
                default:
                    System.out.println("Categoria inválida. Digite HELP para ver as opções.");
                    break;
            }
        } while (!isValidInput);
        return category;
    }   

    
    public void showAllTrainers() {
        loadTrainerData(TRAINER_DATA_FILE);
            if (trainers.isEmpty()) {
            System.out.println("Nenhum treinador cadastrado.");
        } else {
            System.out.println("\n----Lista de treinadores----\n");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (Trainer trainer : trainers) {
                System.out.println("Número de Treinador: " + trainer.getTrainerNumber());
                System.out.println("Nome: " + trainer.getName());
                System.out.println("Data de nascimento: " + sdf.format(trainer.getDateBirthday()));
                System.out.println("Data de entrada: " + sdf.format(trainer.getEntryDate()));
                System.out.println("Categoria: " + trainer.getCategory());
                System.out.println("---------------\n");
            }
        }
    }


    
    public void searchTrainer() {
        if (trainers.isEmpty()) {
            System.out.println("Nenhum treinador cadastrado.");
            return;
        }
        
        int trainerNumber = reader.getNumberTrainer("Digite o numero a ser pesquisado: ");
        
        for (Trainer trainer : trainers) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            if (trainer.getTrainerNumber() == trainerNumber) {
                System.out.println("Número de Treinador: " + trainer.getTrainerNumber());
                System.out.println("Nome: " + trainer.getName());
               System.out.println("Data de entrada: " + sdf.format(trainer.getEntryDate()));
                System.out.println("Categoria: " + trainer.getCategory());
                return;
            }
        }
        
        System.out.println("Não foram encontrados treinadores.");
    }



    
    public void showTrainerContainsName(String search) {
        if (trainers.isEmpty()) {
            System.out.println("Nenhum treinador cadastrado.");
            return;
        }
        
        if (search == null || search.trim().isEmpty()) {
            Scanner scanner = new Scanner(System.in); // define a new Scanner object
            System.out.print("Digite o nome a ser pesquisado: ");
            search = scanner.nextLine(); // get the user input
        }
        
            System.out.println("---- Treinadores cujo nome contém \"" + search + "\" ----\n");
            boolean foundTrainer = false; // add a flag to keep track of whether any trainers have been found
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            
            for (Trainer trainer : trainers) {
                String trainerName = trainer.getName();
                
                if (trainerName.toLowerCase().contains(search.toLowerCase())) {
                    foundTrainer = true;
                    System.out.println("Número de Treinador: " + trainer.getTrainerNumber());
                    System.out.println("Nome: " + trainerName);
                    System.out.println("Data de entrada: " + sdf.format(trainer.getEntryDate()));
                    System.out.println("Categoria: " + trainer.getCategory());
                    System.out.println("-------------------------");
                }
            }
            
            if (!foundTrainer) { // if no trainers were found, print an error message
                System.out.println("Não foram encontrados treinadores com o nome '" + search + "'.");
            }
        
    }

    
    
public void changeTrainerInfo() {
    if (trainers.isEmpty()) {
            System.out.println("Não há treinadores cadastrados.");
            return;
        }
        
        boolean continueChanging = true;
    while (continueChanging) {
         System.out.println("_____________________________________");
            System.out.println("\n************** Alterar Treinador *******************\n\t\t\t\t");
            int trainerNumber = reader.getNumberTrainer("Digite o número do treinador:"); // Asks to enter trainer number
            Trainer trainer = null;

        
        for (Trainer t : trainers) {
                if (t.getTrainerNumber() == trainerNumber) {
                    trainer = t;
                    break;
                }
            }

        if (trainer == null) {
                System.out.println("Treinador não encontrado.");
                continue;
        }  else {
            System.out.println("Informações do treinador " + trainerNumber + " >");
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                System.out.println("Nome do Treinador: " + trainer.getName());
                System.out.println("Data de entrada: " + sdf.format(trainer.getEntryDate()));
                System.out.println("Categoria: " + trainer.getCategory());
                System.out.println("O que deseja alterar?");
                int option = Menu.menuAlterarTrainer();

            switch (option) {
                case 1:
                    System.out.println("Alterando todas as informações do treinador " + trainerNumber + "...");
                        String newName = reader.getName("Nome do Treinador: ");
                        TrainerCategory category = trainer.getCategory();
                        trainer.setName(newName);
                        trainer.setCategory(category);
                        System.out.println("Todas as informações do treinador " + trainerNumber + " foram alteradas com sucesso.");
                        break;

                case 2:
                     System.out.println("Nome do Treinador atual: " + trainer.getName());
                        String name = reader.getName("Nome do Treinador novo: ");
                        trainer.setName(name);
                        System.out.println("Alterado com sucesso. Nome atual do treinador " + trainerNumber + ": " + trainer.getName());
                        break;

                case 3:
                    Date oldDateBirthday = trainer.getDateBirthday();
                    System.out.println("Data de nascimento atual: " + sdf.format(oldDateBirthday));
                    Date dateBirthday = reader.getDateBirthday("Data de nascimento novo: ");
                    trainer.setDateBirthday(dateBirthday);
                    System.out.println("Alterado com sucesso. Data de nascimento atual do jogador " + trainer.getTrainerNumber() + ": " + sdf.format(dateBirthday));
                    break;

                
                 case 4:
                        TrainerCategory oldCategory = trainer.getCategory();
                        TrainerCategory newCategory = null;
                        boolean validCategory = false;
                        
                        while (!validCategory) {
                            String input = reader.getString("Nova categoria (TP/TA/PP/GR): ");
                            
                            switch (input.toUpperCase()) {
                                case "TP":
                                    newCategory = TrainerCategory.MAIN;
                                    validCategory = true;
                                    break;
                                case "TA":
                                    newCategory = TrainerCategory.ASSISTANT;
                                    validCategory = true;
                                    break;
                                case "PP":
                                    newCategory = TrainerCategory.PERSONAL;
                                    validCategory = true;
                                    break;
                                case "GR":
                                    newCategory = TrainerCategory.GOALKEEPER;
                                    validCategory = true;
                                    break;
                                case "HELP":
                                    System.out.println("Opções de categoria: ");
                                    
                                    for (TrainerCategory c : TrainerCategory.values()) {
                                        System.out.println(c.toChar() + " - " + c.toString());
                                    }
                                    
                                    break;
                                default:
                                    System.out.println("Categoria inválida. Digite HELP para ver as opções.");
                                    break;
                            }
                        }
                        
                        trainer.setCategory(newCategory);
                        System.out.println("Categoria alterada com sucesso.");
                        
                       
                        break;
                        

                case 5:
                    break;

                default:
                    System.out.println("Opção inválida. Por favor, tente novamente.");
                    break;
            }
        }

        continueChanging = reader.getBoolean("Deseja alterar mais alguma informação do jogador? (s/n)");
    }
    }


    public void saveTrainerData(String fileName) {
        try (OutputStream outputStream = new FileOutputStream(fileName);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream)) {
    
            // Write the trainers and teams lists to the file
            objectOutputStream.writeObject(trainers);
            objectOutputStream.writeObject(teams);
    
            // Iterate over the teams and players to retrieve and save their ratings
            for (Team team : teams) {
                for (Player player : team.getSelectedPlayers()) {
                    List<Integer> playerRatings = player.getPlayerRatings();
                    objectOutputStream.writeObject(playerRatings);
                }
            }
    
            System.out.println("Trainer and team data saved successfully to " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving trainer and team data to " + fileName + ": " + e.getMessage());
        }
    }






    public void loadTrainerData(String fileName) {
        try (InputStream inputStream = new FileInputStream(fileName);
             ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
    
            // Read the trainers and teams lists from the file
            trainers = (ArrayList<Trainer>) objectInputStream.readObject();
            teams = (ArrayList<Team>) objectInputStream.readObject();
    
            System.out.println("Trainer data loaded successfully from " + fileName);
        } catch (Exception e) {
            System.out.println("Error loading trainer data from " + fileName + ": " + e.getMessage());
        }
    }
   

     public void loadTeamData(String fileName) {
        try (InputStream inputStream = new FileInputStream(fileName);
             ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
            teams = (ArrayList<Team>) objectInputStream.readObject();
            System.out.println("Team data loaded successfully from " + fileName);
        } catch (FileNotFoundException e) {
            System.out.println("Team data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error loading team data from " + fileName + ": " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading team data: " + e.getMessage());
        }
    }
    



}
