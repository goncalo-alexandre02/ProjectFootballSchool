import java.util.ArrayList;
import java.util.Scanner;
import java.io.Serializable;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.HashSet;
import java.text.SimpleDateFormat;

public class Team implements Serializable {
    private String teamName;
    private ArrayList<Player> players;
    private ArrayList<Trainer> trainers;
    private Trainer selectedTrainer; // Declare selectedTrainer as an instance variable
    private ArrayList<Player> selectedPlayers;
    private static ArrayList<Team> teams = new ArrayList<>();
    private static final String TRAINER_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/trainer_data.bin";
    private static final String PLAYER_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/player_data.bin";
    private static final String TEAM_DATA_FILE = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/teams_data.bin";
    private static final long serialVersionUID = 7115675816859174935L;
    private InputReader reader;
    private TeamLevel teamLevel;
    

    public Team() {
        this.teamName = teamName;
        this.trainers = new ArrayList<>();
        this.players = new ArrayList<>();
        this.selectedTrainer = null;
        this.selectedPlayers = new ArrayList<>();
    }      


    public void addPlayer(Player player) {
        players.add(player);
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public ArrayList<Trainer> getTrainers() {
        return trainers;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public Trainer getSelectedTrainer() {
        return selectedTrainer;
    }

    public void setSelectedTrainer(Trainer selectedTrainer) {
        this.selectedTrainer = selectedTrainer;
    }


    public ArrayList<Player> getSelectedPlayers() {
        return selectedPlayers;
    }

    public void addSelectedPlayer(Player player) {
        selectedPlayers.add(player);
    }
    
    public TeamLevel getTeamLevel() {
        return teamLevel;
    }
    
    public void setTeamLevel(TeamLevel level) {
        this.teamLevel = level;
    }



    public Player getPlayerByNumber(int playerNumber) {
        for (Player player : selectedPlayers) {
            if (player.getPlayerNumber() == playerNumber) {
                return player;
            }
        }
        return null; // Jogador com o número especificado não encontrado
    }

    
    public void makeTeam() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("_____________________________________");
    System.out.println("\n************** Criar uma nova equipe *******************\n");

    System.out.print("Nome da equipe: ");
    String teamName = scanner.nextLine();
    setTeamName(teamName);

    System.out.print("Escalões da Equipa (S7/S9/S11): ");
    String levelAbbreviation = scanner.nextLine().toUpperCase();
    TeamLevel level = TeamLevel.fromAbbreviation(levelAbbreviation);
    while (level == null) {
        System.out.println("Escalão inválido. Digite novamente.");
        System.out.print("Escalões da Equipa (S7/S9/S11): ");
        levelAbbreviation = scanner.nextLine().toUpperCase();
        level = TeamLevel.fromAbbreviation(levelAbbreviation);
    }
    this.teamLevel = level;

    System.out.println("Treinadores disponíveis:");
    for (int i = 0; i < this.trainers.size(); i++) {
        Trainer trainer = this.trainers.get(i);
        System.out.println("Número de Treinador: " + trainer.getTrainerNumber());
        System.out.println("Nome: " + trainer.getName());
    }

    int selectedTrainerNumber;
    do {
        System.out.print("Selecione o número do treinador: ");
        selectedTrainerNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        if (selectedTrainerNumber <= 0 || selectedTrainerNumber > this.trainers.size()) {
            System.out.println("Erro: Número de treinador inválido. Tente novamente.");
        } else {
            selectedTrainer = this.trainers.get(selectedTrainerNumber - 1);
            break; // Exit the loop after a valid selection
        }
    } while (true);

    Team team = new Team(); // Create a new instance of the Team class
    team.setTeamName(teamName); // Set the team name
    team.setTeamLevel(level); // Set the team level
    team.setSelectedTrainer(selectedTrainer); // Set the selected trainer

    boolean addPlayer = true;
    while (addPlayer) {
        System.out.println("Jogadores disponíveis:");
        boolean playerFound = false;
        for (int i = 0; i < this.players.size(); i++) {
            Player player = this.players.get(i);
            if (player.getTeam() == null) {
                System.out.println("Número de Jogador: " + player.getPlayerNumber());
                System.out.println("Nome: " + player.getName());
                playerFound = true;
            }
        }

        if (!playerFound) {
            System.out.println("Todos os jogadores estão atribuídos a equipes.");
            break; // Exit the loop if no players are available
        }

        int selectedPlayerNumber;
        do {
            System.out.print("Selecione o número do Jogador: ");
            selectedPlayerNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            boolean validSelection = false;
            for (int i = 0; i < this.players.size(); i++) {
                Player selectedPlayer = this.players.get(i);
                if (selectedPlayer.getPlayerNumber() == selectedPlayerNumber && selectedPlayer.getTeam() == null) {
                    team.addSelectedPlayer(selectedPlayer); // Add the selected player to the team
                    selectedPlayer.setTeam(team); // Set the player's team to the current team
                    validSelection = true;
                    System.out.println("Jogador adicionado com sucesso à equipe!");
                    break; // Exit the loop after a valid selection
                }
            }

            if (!validSelection) {
                System.out.println("Erro: Número de jogador inválido ou já atribuído a outra equipe. Tente novamente.");
            } else {
                break; // Exit the loop after a valid selection
            }
        } while (true);

        System.out.print("Deseja adicionar mais jogadores? (S/N): ");
        String continueAdding = scanner.nextLine().toUpperCase();
        addPlayer = continueAdding.equals("S");
    }

    this.teams.add(team); // Add the created team to the list of teams

    System.out.println("\t\t\t******** Criado com sucesso ********\t\t\t");
}





    public void changeTeamInfo() {
        if (teams.isEmpty()) {
            System.out.println("Não há equipes cadastradas.");
            return;
        }
    
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome da equipe: ");
        String teamName = scanner.nextLine();
        Team team = null;
        for (Team t : teams) {
            if (t.getTeamName().equalsIgnoreCase(teamName)) {
                team = t;
                break;
            }
        }
    
        if (team == null) {
            System.out.println("Equipe não encontrada.");
            return;
        }
    
        boolean continueChanging = true;
    
        while (continueChanging) {
        
            int option = Menu.menuAlterarTeam();
    
        switch (option) {
            
            case 1:
               
                System.out.println("Nome da equipe atual: " + team.getTeamName());
                System.out.print("Novo nome da equipe: ");
                String newTeamName = scanner.nextLine();
                team.setTeamName(newTeamName);
                System.out.println("Nome da equipe alterado com sucesso!");
                break;
            
    
            case 2:
                System.out.println("Treinador atual:");
                System.out.println("Número de Treinador: " + team.getSelectedTrainer().getTrainerNumber());
                System.out.println("Nome: " + team.getSelectedTrainer().getName());
                System.out.println("--------------------");
                System.out.println("Treinadores disponíveis:");
                for (Trainer trainer : trainers) {
                    System.out.println("Número de Treinador: " + trainer.getTrainerNumber());
                    System.out.println("Nome: " + trainer.getName());
                }
                int selectedTrainerNumber;
                do {
                    System.out.print("Selecione o número do novo treinador: ");
                    selectedTrainerNumber = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character
    
                    if (selectedTrainerNumber <= 0 || selectedTrainerNumber > trainers.size()) {
                        System.out.println("Erro: Número de treinador inválido. Tente novamente.");
                    } else {
                        Trainer selectedTrainer = trainers.get(selectedTrainerNumber - 1);
                        setSelectedTrainer(selectedTrainer);
                        System.out.println("Treinador da equipe alterado com sucesso!");
                        break; // Exit the loop after a valid selection
                    }
                } while (true);
                break;
            case 3:
        Set<Integer> assignedPlayerNumbers = new HashSet<>();
        for (Team t : teams) {
            for (Player player : t.getSelectedPlayers()) {
                assignedPlayerNumbers.add(player.getPlayerNumber());
            }
        }
    
        System.out.println("Jogadores disponíveis:");
        boolean playersAvailable = false;
        for (Player player : players) {
            if (!assignedPlayerNumbers.contains(player.getPlayerNumber())) {
                System.out.println("Número de Jogador: " + player.getPlayerNumber());
                System.out.println("Nome: " + player.getName());
                playersAvailable = true;
            }
        }
    
        if (!playersAvailable) {
            System.out.println("Todos os jogadores estão atribuídos a equipes.");
        } else {
        int selectedPlayerNumber;
        do {
            System.out.print("Selecione o número do jogador a ser adicionado: ");
            selectedPlayerNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
    
            boolean playerFound = false;
            for (Player player : players) {
                if (player.getPlayerNumber() == selectedPlayerNumber && player.getTeam() == null) {
                    team.addSelectedPlayer(player); // Add the selected player to the team
                    player.setTeam(team); // Set the player's team
                    playerFound = true;
                    System.out.println("Jogador adicionado com sucesso à equipe!");
                    break;
                }
            }
    
            if (!playerFound) {
                System.out.println("Erro: Número de jogador inválido ou já atribuído a outra equipe. Tente novamente.");
            } else {
                break; // Exit the loop after a valid selection
            }
        } while (true);
        }
        
        break;
    
    case 4:
                System.out.println("Jogadores na equipe:");
        for (Player player : team.getSelectedPlayers()) {
            System.out.println("Número de Jogador: " + player.getPlayerNumber());
            System.out.println("Nome: " + player.getName());
        }
    
    int removePlayerNumber;
    do {
        System.out.print("Selecione o número do jogador a ser removido: ");
        removePlayerNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
    
        boolean playerFound = false;
        Player playerToRemove = null;
        for (Player player : team.getSelectedPlayers()) {
            if (player.getPlayerNumber() == removePlayerNumber) {
                playerFound = true;
                playerToRemove = player;
                break;
            }
        }
    
        if (!playerFound) {
            System.out.println("Erro: Número de jogador inválido. Tente novamente.");
        } else {
            team.getSelectedPlayers().remove(playerToRemove);
            System.out.println("Jogador removido com sucesso da equipe!");
            break; // Exit the loop after removing the player
        }
    } while (true);
        break;
    
        case 5:
            // Delete Team
                 System.out.println("Informações da equipe " + team.getTeamName() + " >");
                System.out.println("Escalão: " + team.getTeamLevel());

                System.out.print("Deseja realmente excluir esta equipe? (s/n): ");
                String confirmDeletion = scanner.nextLine();
                if (confirmDeletion.equalsIgnoreCase("s")) {
                    teams.remove(team);
                    System.out.println("Equipe removida com sucesso.");
                    continueChanging = false;
                } else {
                    System.out.println("Eliminação cancelada. Voltando ao menu...");
                }
                break;

           case 6:
        continueChanging = false;
        System.out.println("Retornando ao menu principal...");
        break;
    
                    default:
                        System.out.println("Opção inválida. Por favor, tente novamente.");
                        break;
                }
            }    
    }



    
    public void searchTeamByName(String name) {
        boolean found = false;
        for (Team team : teams) {
            if (team.getTeamName().equalsIgnoreCase(name)) {
                System.out.println("Nome da equipe: " + team.getTeamName());
               System.out.println("\n---------------------\n");
                System.out.println("Treinador:");
                Trainer selectedTrainer = team.getSelectedTrainer();
                if (selectedTrainer != null) {
                    System.out.println("Número de Treinador: " + selectedTrainer.getTrainerNumber());
                    System.out.println("Nome: " + selectedTrainer.getName());
                    System.out.println("\n---------------------\n");
                } else {
                    System.out.println("Treinador não selecionado.");
                }
                System.out.println("Jogadores:");
                for (Player player : team.getSelectedPlayers()) {
                    System.out.println("Número de Jogador: " + player.getPlayerNumber());
                    System.out.println("Nome: " + player.getName());
                    System.out.println("\n---------------------\n");
                }
                System.out.println("---------------");
                found = true;
            }
        }
        if (!found) {
            System.out.println("Nenhuma equipe encontrada com o nome: " + name);
        }
    }
    
    
public void removePlayer(int playerNumber) {
    InputReader reader = new InputReader(); // Instantiate the InputReader object

    Player playerToRemove = null;
    for (Player player : players) {
        if (player.getPlayerNumber() == playerNumber) {
            playerToRemove = player;
            break;
        }
    }

    if (playerToRemove == null) {
        System.out.println("Jogador não encontrado na equipe.");
        return;
    }

    System.out.println("Informações do jogador " + playerToRemove.getPlayerNumber() + " >");
    System.out.println("Nome do Jogador: " + playerToRemove.getName());

    System.out.println("Número da camisola: " + playerToRemove.getNumberShirt());

boolean confirmDeletion = reader.getBoolean("Deseja realmente excluir este jogador? (s/n)");
    if (confirmDeletion) {
        players.remove(playerToRemove);
        System.out.println("Jogador removido com sucesso.");
        selectedPlayers.remove(playerToRemove);
        savePlayerData(PLAYER_DATA_FILE); // Replace PLAYER_DATA_FILE with the appropriate file path

    } else {
        System.out.println("Exclusão cancelada. Voltando ao menu...");
    }
}


    
    
   public void listTeamsByName(String name) {
    boolean found = false;
    for (Team team : teams) {
        if (team.getTeamName().toLowerCase().contains(name.toLowerCase())) {
            System.out.println("Nome da equipe: " + team.getTeamName());
            System.out.println("\n---------------------\n");
            
            Trainer selectedTrainer = team.getSelectedTrainer();
            System.out.println("Treinador:");
            System.out.println("Número de Treinador: " + selectedTrainer.getTrainerNumber());
            System.out.println("Nome: " + selectedTrainer.getName());
            System.out.println("\n---------------------\n");
            
            System.out.println("Jogadores:");
            for (Player player : team.getSelectedPlayers()) {
                System.out.println("Número de Jogador: " + player.getPlayerNumber());
                System.out.println("Nome: " + player.getName());
                System.out.println("\n---------------------\n");
            }
            System.out.println("\n---------------");
            found = true;
        }
    }
    if (!found) {
        System.out.println("Nenhuma equipe encontrada com o nome: " + name);
    }
}

    
    public void listTeamsByTrainer(int trainerNumber) {
        boolean found = false;
        for (Team team : teams) {
            Trainer selectedTrainer = team.getSelectedTrainer();
            if (selectedTrainer != null && selectedTrainer.getTrainerNumber() == trainerNumber) {
                System.out.println("Nome da equipe: " + team.getTeamName());
                System.out.println("\n---------------------\n");
                System.out.println("Treinador:");
                System.out.println("Número de Treinador: " + selectedTrainer.getTrainerNumber());
                System.out.println("Nome: " + selectedTrainer.getName());
               System.out.println("\n---------------------\n");
                System.out.println("Jogadores:");
                for (Player player : team.getSelectedPlayers()) {
                    System.out.println("Número de Jogador: " + player.getPlayerNumber());
                    System.out.println("Nome: " + player.getName());
                    System.out.println("\n---------------------\n");
                }
                System.out.println("\n---------------");
                found = true;
            }
        }
        if (!found) {
            System.out.println("Nenhuma equipe encontrada com o número de treinador: " + trainerNumber);
        }
    }
    
    
    
    
    

  public void showAllTeams() {
    if (teams.isEmpty()) {
        System.out.println("Nenhuma equipe cadastrada.");
        return;
    }

    System.out.println("\n----Lista de equipes----\n");
    for (Team team : teams) {
        System.out.println("Nome da equipe: " + team.getTeamName());
        System.out.println("Escalão: " + team.getTeamLevel());// Use the teamLevel variable to display the team level
        System.out.println("---------------------\n");
        System.out.println("Treinador:");

        Trainer selectedTrainer = team.getSelectedTrainer(); // Get the selected trainer
        if (selectedTrainer != null) {
            System.out.println("Número de Treinador: " + selectedTrainer.getTrainerNumber());
            System.out.println("Nome: " + selectedTrainer.getName());
            System.out.println("\n---------------------\n");
        } else {
            System.out.println("Treinador não selecionado.");
        }

        System.out.println("Jogadores:");
        ArrayList<Player> selectedPlayers = team.getSelectedPlayers(); // Get the selected players
        if (!selectedPlayers.isEmpty()) {
            for (Player player : selectedPlayers) {
                System.out.println("Número de Jogador: " + player.getPlayerNumber());
                System.out.println("Nome: " + player.getName());
                System.out.println("\n---------------------\n");
            }
        } else {
            System.out.println("Jogadores não selecionados.");
        }

        System.out.println("---------------\n");
    }
}






    public void loadPlayerData(String fileName) {
        try (InputStream inputStream = new FileInputStream(fileName);
             ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
            players = (ArrayList<Player>) objectInputStream.readObject();
            System.out.println("Player data loaded successfully from " + fileName);
        } catch (FileNotFoundException e) {
            System.out.println("Player data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error loading player data from " + fileName + ": " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading player data: " + e.getMessage());
        }
    }

    public void loadTrainerData(String fileName) {
        try (InputStream inputStream = new FileInputStream(fileName);
             ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
            trainers = (ArrayList<Trainer>) objectInputStream.readObject();
            System.out.println("Trainer data loaded successfully from " + fileName);
        } catch (FileNotFoundException e) {
            System.out.println("Trainer data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error loading trainer data from " + fileName + ": " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading trainer data: " + e.getMessage());
        }
    }

    public void loadTeamData(String fileName) {
    try (InputStream inputStream = new FileInputStream(fileName);
         ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
        teams = (ArrayList<Team>) objectInputStream.readObject();
        System.out.println("Team data loaded successfully from " + fileName);
    } catch (FileNotFoundException e) {
        System.out.println("Team data file not found: " + fileName);
    } catch (IOException e) {
        System.out.println("Error loading team data from " + fileName + ": " + e.getMessage());
    } catch (ClassNotFoundException e) {
        System.out.println("Error loading team data: " + e.getMessage());
    }
}

public void savePlayerData(String fileName) {
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            objectOutputStream.writeObject(players);
            // objectOutputStream.writeInt(nextPlayerNumber); // Save the nextPlayerNumber
            System.out.println("Player data saved successfully to " + fileName);
        } catch (FileNotFoundException e) {
            System.out.println("Player data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving player data to " + fileName + ": " + e.getMessage());
        }
    }
    
    public void saveTeamData(String fileName) {
        try (OutputStream outputStream = new FileOutputStream(fileName);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream)) {
            objectOutputStream.writeObject(this.teams);
            System.out.println("Team data saved successfully to " + fileName);
        } catch (FileNotFoundException e) {
            System.out.println("Team data file not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving team data to " + fileName + ": " + e.getMessage());
        }
    }
}
