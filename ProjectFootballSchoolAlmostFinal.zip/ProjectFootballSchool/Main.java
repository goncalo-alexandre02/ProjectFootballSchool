import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
import java.util.Scanner;
import java.io.IOException;

public class Main implements Serializable {
    private static ArrayList<Player> players = new ArrayList<>();
    String playerDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/player_data.bin";
    String trainerDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/trainer_data.bin";
    String teamDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/teams_data.bin";
       

    public static void main(String[] args) {
        // Specify the file path for the binary player data file
        int option;
        String playerDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/player_data.bin";
        String trainerDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/trainer_data.bin";
        String teamDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/teams_data.bin";
       InputReader reader = new InputReader();
        
        do {
            option = Menu.generalMenu();
            switch (option) {
                case 1:
                    mainPlayer(playerDataFile, reader);
                    break;
                case 2:
                     mainTrainer(trainerDataFile, reader);
                    break;
                case 3:
                     mainTeam(teamDataFile,trainerDataFile, playerDataFile, reader);
                    break;
            }
        } while (option != 4);
    }

   private static void mainPlayer(String playerDataFile, InputReader reader) {
    Player player = new Player();
    
    // Load existing player data at the beginning
    player.loadPlayerData(playerDataFile);
    
    int option;
    do {
        option = Menu.menuJogador();  // Assuming you have a separate menu for player operations
        switch (option) {
            case 1:
                player.makePlayer();
                break;
            case 2:
                player.changePlayerInfo();
                break;
            case 3:
                player.searchPlayer();
                break;
            case 4:
                String searchTerm = reader.getName("Nome Contem: ");
                player.showPlayersContainsName(searchTerm);
                break;
            case 5:
                player.showAllPlayers();
                break;
            case 6:
                int playerNumber = reader.getIntegerNumber("Digite o número do jogador a ser removido: ");
                player.removePlayerByNumber(playerNumber);
                break;
            case 7:
                    player.savePlayerData(playerDataFile);
                break;
            case 8:
                System.out.println("Returning to the main menu...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
                break;
        }
    } while (option != 8);
}



    
    private static void mainTrainer(String trainerDataFile, InputReader reader) {
    Trainer trainer = new Trainer();
     Player player = new Player();
    List<Integer> playerRatings = new ArrayList<>();
    int option;
    trainer.loadTrainerData(trainerDataFile);
    Scanner scanner = new Scanner(System.in);
    String teamDataFile = "/Users/goncaloalexandre/Documents/POO/ProjectFootballSchool/teams_data.bin";
    trainer.loadTeamData(teamDataFile);

    do {
        option = Menu.menuTrainer();  // Assuming you have a separate menu for trainer operations
        switch (option) {
            case 1:
                trainer.makeTrainer();
                break;
            case 2:
                trainer.changeTrainerInfo();
                break;
            case 3:
                trainer.searchTrainer();
                break;
            case 4:
                String searchTerm = reader.getName("Nome Contém: ");
                trainer.showTrainerContainsName(searchTerm);
                break;
            case 5:
                trainer.showAllTrainers();
                break;
           case 6:
               trainer.evaluatePlayers(scanner, player.getPlayerRatings());

                break;
            case 7:
                trainer.saveTrainerData(trainerDataFile);
                break;
            case 8:
                System.out.println("Returning to main menu...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
                break;
        }
    } while (option != 8);
}

private static void mainTeam(String teamDataFile, String trainerDataFile, String playerDataFile, InputReader reader) {
     Team team = new Team();
    ArrayList<Trainer> trainers = new ArrayList<>();
    ArrayList<Player> players = new ArrayList<>();

    // Load trainer data
    team.loadTrainerData(trainerDataFile);

    // Load player data
    team.loadPlayerData(playerDataFile);

    // Load trainer data
    team.loadTeamData(teamDataFile);

    int option;

    do {
        option = Menu.menuTeam();
        switch (option) {
            case 1:
                team.makeTeam(); // Assuming you have a method to create a team
                break;
            case 2:
                team.changeTeamInfo();
                // Add code for changing team information
                break;
            case 3:
                // Add code for searching team information
                //team.searchTeamByName();
                break;
            case 4:
                // Add code for listing teams
              String searchTerm = reader.getName("Nome Contém: ");
                team.listTeamsByName(searchTerm);
                break;
            case 5:
                // Add code for listing all team players by coach number

                team.showAllTeams();
                break;
            case 6:
                // Add code for listing all team players by coach number
                int trainerNumber = reader.getIntegerNumber("Enter the coach number to list players: ");
                team.listTeamsByTrainer(trainerNumber);
                break;
            case 7:
                int playerNumber = reader.getIntegerNumber("Digite o número do jogador a ser removido: ");
                team.removePlayer(playerNumber);


                break;
            case 8:
               team.saveTeamData(teamDataFile);
                    
                    break;
            case 9:
                System.out.println("Returning to main menu...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
                break;
        }
    } while (option != 9);
}




}
