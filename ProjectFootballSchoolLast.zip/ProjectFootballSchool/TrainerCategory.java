
/**
 * Escreva uma descrição da classe TrainerCategory aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public enum TrainerCategory {
    MAIN("TP", "Treinador Principal"),
    ASSISTANT("TA", "Treinador Assistente"),
    PERSONAL("PP", "Preparador Físico"),
    GOALKEEPER("GR", "Treinador de Guarda-Redes");

    private final String code;
    private final String description;

    TrainerCategory(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static TrainerCategory fromCode(String code) {
        for (TrainerCategory category : TrainerCategory.values()) {
            if (category.getCode().equalsIgnoreCase(code)) {
                return category;
            }
        }
        return null;
    }

    public static void printCategories() {
        System.out.println("Opções de categoria: ");
        for (TrainerCategory category : TrainerCategory.values()) {
            System.out.println(category.getCode() + " - " + category.getDescription());
        }
    }

    @Override
    public String toString() {
        return description;
    }

    public static TrainerCategory getTrainerCategory(InputReader reader) {
        TrainerCategory category = null;
        boolean isValidInput = false;
        do {
            System.out.print("Categoria do treinador (TP/TA/PP/GR): ");
            String input = reader.nextLine().toUpperCase();
            category = TrainerCategory.fromCode(input);
            if (category != null) {
                isValidInput = true;
            } else if (input.equals("HELP")) {
                TrainerCategory.printCategories();
            } else {
                System.out.println("Categoria inválida. Digite HELP para ver as opções.");
            }
        } while (!isValidInput);
        return category;
    }
}


