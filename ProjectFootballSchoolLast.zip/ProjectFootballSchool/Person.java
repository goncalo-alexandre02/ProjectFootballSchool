import java.util.Date;
import java.io.Serializable;

/**
 * Escreva uma descrição da classe Person aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Person implements Serializable
{
    // variáveis de instância
    public String name;
    private Date dateBirthday;
    private Date entryDate;

    public Person(String name, Date dateBirthday, Date entryDate) {
        if(name !=null){
           this.name = name;
        }
        if(dateBirthday !=null){
           this.dateBirthday = dateBirthday;
        }
        if(entryDate !=null){
           this.entryDate = entryDate;
        }
    }

    public Person() {
        // Empty constructor
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDateBirthday() {
        return dateBirthday;
    }

    public void setDateBirthday(Date dateBirthday) {
        this.dateBirthday = dateBirthday;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }
}
