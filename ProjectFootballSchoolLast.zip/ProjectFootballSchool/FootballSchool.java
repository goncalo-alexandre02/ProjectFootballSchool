
/**
 * Escreva uma descrição da classe FootballSchool aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class FootballSchool
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String name;
    private String date;
    private String address;

    /**
     * Construtor para objetos da classe FootballSchool
     */
    public FootballSchool()
    {
        // inicializa variáveis de instância
        name = "G.A";
        date="26/04/1904";
        address = "Setúbal";
        
    }
    
    public String getName() 
    { 
        return name; 
    }

}
